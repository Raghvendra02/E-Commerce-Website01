﻿var lang = {
    added_to_cart: "Added to cart",
    error_to_cart: "Problem with shopping cart! Try again!",
    no_products: "No products",
    confirm_clear_cart: "Are you sure want to delete items in shopping cart?",
    cleared_cart: "Your cart is empty",
    are_you_sure: "Are you sure?",
    yes: "Yes",
    no: "No",
    clear_all: "Clear",
    checkout: "Payment",
    remove_from_cart: "Deleted from shopping cart",
    enter_valid_email: "Please enter a valid email address",
    discountCodeInvalid: "Discount code is invalid"
};